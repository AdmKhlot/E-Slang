package com.example.willi.e_slang;

/**
 * Created by Adm. Aken Bosch on 29/05/2017.
 */

public final class Config {

        private Config() {
        }

        public static final String YOUTUBE_API_KEY = "AIzaSyAbnpFL3NhxOzdqTiu696qQCT_v7680k6g";

    }
